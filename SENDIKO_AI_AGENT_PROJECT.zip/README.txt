SENDIKO AI AGENT - Starter project

This is a minimal native Android starter project. It is not yet an AI agent and does not yet control other apps.
Target device compatibility: Android 8.0+ (including Android 11).

To build the APK, the repository must contain the extracted project files at its root and a GitHub Actions workflow at .github/workflows/android.yml.
The build workflow is provided separately in BUILD_WORKFLOW.txt because GitHub does not run workflows contained inside an uploaded ZIP until they are committed as repository files.
