package com.sendiko.aiagent

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(245, 248, 252))
        }
        val title = TextView(this).apply {
            text = "SENDIKO AI AGENT"
            textSize = 26f
            setTextColor(Color.rgb(16, 42, 67))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Asisten kerja pintar Anda\n\nVersi awal aplikasi sudah terpasang. Fitur AI dan otomatisasi akan ditambahkan bertahap."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 28)
        }
        val status = TextView(this).apply {
            text = "Status: aplikasi siap dibuka"
            textSize = 15f
            setTextColor(Color.rgb(30, 110, 70))
            gravity = Gravity.CENTER
        }
        val button = Button(this).apply {
            text = "MULAI"
            setOnClickListener { status.text = "Status: SENDIKO siap dikembangkan" }
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(button)
        setContentView(root)
    }
}
